R Notebook file is called operational.Rnw
It contains a few notes on use at the top which are copied here:

%This is a knitr/sweave document that should compile with a single click in RStudio
%if you have the necessary packages installed.

%As saved, it does *NOT* do the calculations and make figures (which are included)
%It tqkes about an hour to do all calculations and figures on my laptop, you can
%switch these on country by country by setting eval=T in the relevant chunks eg change
%<<runmonte-UK, eval=F, include=F>>=
%to
%<<runmonte-UK, eval=T, include=F>>=
%below in the document to make the UK figures.

%latex needs compiling twice to make the pdf, due to references etc. But you
%don't need to remake the figures, they are saved in a subdirectory

%This paper uses the:

%% Copernicus Publications Manuscript Preparation Template for LaTeX Submissions